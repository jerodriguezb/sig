import React from 'react';
import { Typography } from '@mui/material';

export default function PermissionsPage() {
  return <Typography>Gestor de permisos (pendiente de implementación)</Typography>;
}
