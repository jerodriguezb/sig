import React from 'react';
import { Typography } from '@mui/material';

export default function LogisticsPage() {
  return <Typography>Panel logístico en tiempo real (pendiente)</Typography>;
}
